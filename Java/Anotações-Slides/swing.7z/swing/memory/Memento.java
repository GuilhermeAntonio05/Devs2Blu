package br.com.exemplo.memento.swing.memory;

public interface Memento {

}
