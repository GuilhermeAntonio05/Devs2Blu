package listaexercicios12.principioSRP;

public class Livro {
    private String titulo;
    private Autor autor; // Associa��o
    private Categoria categoria; // Agrega��o
    private boolean alugado;

    public Livro(String titulo, Autor autor) {
        this.titulo = titulo;
        this.autor = autor;
        this.alugado = false;
    }

    public String getTitulo() {
        return titulo;
    }

    public Autor getAutor() {
        return autor;
    }

    public boolean isAlugado() {
        return alugado;
    }

    public void setAlugado(boolean alugado) {
        this.alugado = alugado;
    }


	public Categoria getCategoria() {
		return categoria;
	}


	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	
	
	// Fun��o para alugar um livro
    public void alugar() {
        if (!alugado) {
            alugado = true;
            System.out.println("O livro " + titulo + " foi alugado.");
        } else {
            System.out.println("O livro " + titulo + " j� est� alugado.");
        }
    }

    // Fun��o para gerar relat�rio de livros
    public void gerarRelatorio() {
        System.out.println("T�tulo: " + titulo);
        System.out.println("Autor: " + autor.getNome());
        System.out.println("Status: " + (alugado ? "Alugado" : "Dispon�vel"));
    }  
    
}