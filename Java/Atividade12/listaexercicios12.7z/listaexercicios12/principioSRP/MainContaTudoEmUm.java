package listaexercicios12.principioSRP;

public class MainContaTudoEmUm {
	
	    public static void main(String[] args) {
	        ContaTudoEmUm conta = new ContaTudoEmUm("Jo�o Silva", 500.0);
	        conta.depositar(200.0);
	        conta.sacar(150.0);
	        conta.gerarRelatorioSaldo();
	        conta.gerarRelatorioTransacoes();
	    }
}
