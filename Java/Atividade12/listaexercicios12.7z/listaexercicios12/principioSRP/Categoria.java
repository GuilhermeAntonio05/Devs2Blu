package listaexercicios12.principioSRP;

public class Categoria {
    private String nome;
    // construtor, getters e setters
}