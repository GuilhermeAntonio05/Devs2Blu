package listaexercicios14.principioISP;

class ImpressoraBasica implements Impressora {
    public void imprimirTexto() {
        System.out.println("Imprimindo texto.");
    }

    public void imprimirImagem() {
        throw new UnsupportedOperationException("Impressora b�sica n�o imprime imagens.");
    }

    public void imprimirRelatorioFinanceiro() {
        throw new UnsupportedOperationException("Impressora b�sica n�o imprime relat�rios financeiros.");
    }
}