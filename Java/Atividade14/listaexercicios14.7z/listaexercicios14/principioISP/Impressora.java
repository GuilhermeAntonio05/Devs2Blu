package listaexercicios14.principioISP;

interface Impressora {
    void imprimirTexto();
    void imprimirImagem();
    void imprimirRelatorioFinanceiro();
}