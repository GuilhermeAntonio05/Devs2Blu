package listaexercicios14.principioISP;

interface Notificacao {
    void enviarEmail();
    void enviarSMS();
    void enviarPushNotification();
}
